import React from "react";
import Header from "../components/Header";
import TrackingAnimation from "../components/TrackingAnimation";
import PackageTable from "../components/PackageTable";
import FAQ from "../components/FAQ";
import Contact from "../components/Contact";
import Footer from "../components/Footer";

const HomePage = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-1 space-y-12 px-4 sm:px-6 lg:px-16 py-10">
        <TrackingAnimation />
        <PackageTable />
        <FAQ />
        <Contact />
      </main>

      <Footer />
    </div>
  );
};

export default HomePage;
