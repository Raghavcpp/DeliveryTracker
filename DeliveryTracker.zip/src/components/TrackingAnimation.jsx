import React from "react";
import { Truck, Store, Package, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";

const stages = [
  { label: "In Warehouse", icon: <Package /> },
  { label: "Nearest Store", icon: <Store /> },
  { label: "Dispatched", icon: <Truck /> },
  { label: "Delivered", icon: <CheckCircle /> },
];

const TrackingAnimation = () => {
  return (
    <div className="w-full">
      <h2 className="text-2xl font-semibold text-center mb-8">Package Journey</h2>
      <div className="flex justify-between items-center gap-2 md:gap-6 lg:gap-10 px-4">
        {stages.map((stage, index) => (
          <div className="flex flex-col items-center text-center relative" key={index}>
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: index * 0.3, type: "spring" }}
              className="bg-blue-100 p-4 rounded-full text-blue-600 mb-2"
            >
              {stage.icon}
            </motion.div>
            <span className="text-sm font-medium">{stage.label}</span>
            {/* Connector line */}
            {index < stages.length - 1 && (
              <div className="absolute top-6 right-[-50%] w-full h-1 bg-blue-300 z-[-1] hidden sm:block"></div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default TrackingAnimation;
