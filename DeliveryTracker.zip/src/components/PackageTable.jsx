import React, { useEffect, useState } from "react";

const PackageTable = () => {
  const [packages, setPackages] = useState([]);

  useEffect(() => {
    fetch("/packageData.json")
      .then((res) => res.json())
      .then((data) => setPackages(data.packages))
      .catch((err) => console.error("Failed to load package data:", err));
  }, []);

  return (
    <div>
      <h2 className="text-2xl font-semibold text-center mb-6">Package Details</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white rounded-xl shadow-md">
          <thead className="bg-blue-100 text-blue-700">
            <tr>
              <th className="px-4 py-2 text-left">Package #</th>
              <th className="px-4 py-2 text-left">Customer</th>
              <th className="px-4 py-2 text-left">Store</th>
              <th className="px-4 py-2 text-left">Item</th>
              <th className="px-4 py-2 text-left">Price (₹)</th>
              <th className="px-4 py-2 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {packages.map((pkg, idx) => (
              <tr key={idx} className="border-b hover:bg-gray-50">
                <td className="px-4 py-2">{pkg.packageNumber}</td>
                <td className="px-4 py-2">{pkg.customerName}</td>
                <td className="px-4 py-2">{pkg.storeName}</td>
                <td className="px-4 py-2">{pkg.itemName}</td>
                <td className="px-4 py-2">₹{pkg.itemPrice}</td>
                <td className="px-4 py-2">
                  <span
                    className={`inline-block px-2 py-1 text-sm rounded-full font-medium ${
                      pkg.packageStatus === "Delivered"
                        ? "bg-green-100 text-green-700"
                        : pkg.packageStatus === "On the way"
                        ? "bg-yellow-100 text-yellow-700"
                        : "bg-red-100 text-red-700"
                    }`}
                  >
                    {pkg.packageStatus}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PackageTable;
