import React from "react";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

const Header = () => {
  return (
    <header className="bg-white shadow sticky top-0 z-50">
      <div className="max-w-screen-xl mx-auto px-4 py-4 flex flex-col items-center sm:flex-row sm:justify-between">
        {/* Logo / Brand */}
        <div className="text-2xl font-bold text-blue-600 mb-2 sm:mb-0">
          📦 TrackMyPack
        </div>

        {/* Search Bar */}
        <div className="w-full sm:w-1/2 relative">
          <Input
            type="text"
            placeholder="Enter package number..."
            className="pl-10 pr-4 py-2"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" size={18} />
        </div>
      </div>
    </header>
  );
};

export default Header;
